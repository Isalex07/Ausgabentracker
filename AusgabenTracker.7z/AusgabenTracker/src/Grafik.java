import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.stage.Stage;


public class Grafik extends Application{
    
        PieChart GrafikAusgaben;
        ObservableList<PieChart.Data> ListAusgaben;
        String[] Testdaten = new String[5];
        int[] DatenMenge = new int[5]; 

        public static void main(String[] args) {
            
        }
    
        @Override
        public void start(Stage primaryStage) throws Exception {
            testDatenerzeugen();
            grafikmitDatenfuellen();

            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("GrafikView.fxml"));
            Parent root = fxmlLoader.load();
            Scene Startseite = new Scene(root);
            primaryStage.setTitle("Startseite");
            primaryStage.setScene(Startseite);
            primaryStage.show();
            
        }

        public void grafikmitDatenfuellen(){

            ListAusgaben = FXCollections.observableArrayList();
            
            for(int i=0 ; i < 6 ; i++){
                ListAusgaben.add(new PieChart.Data(Testdaten[i],DatenMenge[i]));
            }
            GrafikAusgaben.setData(ListAusgaben);

        }
        public void testDatenerzeugen(){
                Testdaten [0] = "JAVA";
                DatenMenge[0] = 35;
                
                Testdaten [1] = "PHP";
                DatenMenge[1] = 20;

                Testdaten [2] = "Javascript";
                DatenMenge[2] = 35;                
                
                Testdaten [3] = "C#";
                DatenMenge[3] = 5; 
                
                Testdaten [4] = "COBOL";
                DatenMenge[4] = 5; 
        }
    
  


    

}
